console.log('Hello from Node.js TypeScript template!');
